# FesSms 系统架构分析文档

> 生成日期：2026-04-20  
> 适用环境：UAT / STAGE / PROD

---

## 目录

1. [系统简介](#1-系统简介)
2. [整体架构](#2-整体架构)
3. [SMPP 协议与 SMSC 是什么？](#3-smpp-协议与-smsc-是什么)
4. [短信发送完整流程](#4-短信发送完整流程)
5. [核心类说明](#5-核心类说明)
6. [Config 配置类——各业务模块的 SMSC 连接设定](#6-config-配置类各业务模块的-smsc-连接设定)
7. [白名单机制（UAT 环境保护）](#7-白名单机制uat-环境保护)
8. [已注册的短信服务一览](#8-已注册的短信服务一览)
9. [各业务模块发送的短信内容分析](#9-各业务模块发送的短信内容分析)
10. [`com.logica.smpp` 库详解](#10-comlogicasmpp-库详解)

---

## 1. 系统简介

**FesSms** 是 FES（Front-End System，前端服务系统）的专属 **短信发送服务器**。

它的职责非常单一：**维护与电信运营商短信中心（SMSC）的长连接，并接受内部其他模块的请求，把短信发送到用户的手机**。

它本身不处理任何业务逻辑（例如判断用户是否已签约、计算价格等），纯粹是一个"短信发送工具"。业务逻辑由 **FesWeb**、**FesSoap** 等其他模块负责，这些模块在需要通知用户时，才会呼叫 FesSms。

---

## 2. 整体架构

### ASCII 架构图

```
┌─────────────────────────────────────────────────────────────────┐
│                        FES 系统内部网络                          │
│                                                                 │
│  ┌───────────┐   ┌───────────┐   ┌───────────┐                 │
│  │  FesWeb   │   │  FesSoap  │   │ 其他模块   │  ← 业务模块     │
│  │（前端界面）│   │（SOAP服务）│   │           │                 │
│  └─────┬─────┘   └─────┬─────┘   └─────┬─────┘                 │
│        │               │               │                       │
│        └───────────────┴───────────────┘                       │
│                         │                                       │
│               HTTP POST（序列化任务对象）                        │
│                         ↓                                       │
│              ┌─────────────────────┐                           │
│              │      FesSms         │  ← 本文档分析的系统        │
│              │  (短信发送服务器)    │                           │
│              │                     │                           │
│              │  SmsServlet         │  ← 接收 HTTP 请求         │
│              │  SmsService         │  ← 管理 SMSC 连接池       │
│              │  SmsHandler         │  ← 实际发送短信           │
│              └──────────┬──────────┘                           │
└─────────────────────────┼───────────────────────────────────────┘
                          │
              SMPP 协议（长连接 TCP/IP）
                          ↓
              ┌─────────────────────┐
              │  SMSC（短信中心）    │  ← 电信运营商的服务器
              │ Short Message        │
              │ Service Centre       │
              └──────────┬──────────┘
                         │
              运营商无线网络推送
                         ↓
              ┌─────────────────────┐
              │     用户手机         │  ← 最终收到短信
              └─────────────────────┘
```

### Mermaid 流程图

```mermaid
graph TD
    A[FesWeb / FesSoap<br/>业务模块] -->|HTTP POST 序列化任务| B[FesSms 服务器<br/>SmsServlet]
    B --> C[SmsService<br/>获取/管理连接]
    C --> D[SmsHandler<br/>SMPP Session]
    D -->|SMPP 协议 TCP/IP| E[SMSC<br/>运营商短信中心]
    E -->|无线网络| F[用户手机 📱]
```

---

## 3. SMPP 协议与 SMSC 是什么？

### SMSC（Short Message Service Centre，短信服务中心）

可以把 SMSC 理解为**电信运营商的"短信邮局"**。

当你从手机发一条短信给朋友时，这条短信并不是直接"飞"到朋友手机的——它先送到运营商的 SMSC，SMSC 再负责转发到对方手机。同样，当服务器要发短信给用户，也必须先连接到 SMSC，再由 SMSC 投递到用户手机。

### SMPP（Short Message Peer-to-Peer Protocol，短信点对点协议）

SMPP 是**服务器与 SMSC 之间通信用的专业协议**（不是给普通手机用的）。

- 它是一个 **TCP/IP 长连接**协议（连接一直保持，不需要每次发短信都重新连接）
- 服务器需要用 **System ID + 密码** 向 SMSC 登录（类似账户认证）
- 登录成功后，服务器就可以源源不断地把短信"提交"（submit）给 SMSC
- SMSC 收到后会返回一个 **Message ID** 作为回执

### 用到的开源库

本系统使用 **`com.logica.smpp`** 开源库来处理底层 SMPP 协议细节，开发人员不需要手写 TCP 协议，直接调用 `Session.submit()` 等方法即可。

---

## 4. 短信发送完整流程

### 阶段一：业务模块触发

以"用户签约成功发通知短信"为例：

1. 前端工作人员在 **FesWeb** 完成签约操作
2. 业务逻辑代码调用 **`SmsClient`**（位于 `FesShared` 共享库）

```java
// 例：FesSoap 业务模块中的调用示例
SmsClient client = AppInfo.getSmsClient("CS.Workshop");
client.sendSms(sourceAddress, destAddress, "您的签约已成功，...", false, true);
//                                                            utf8?  big5?
```

`AppInfo.getSmsClient("CS.Workshop")` 会从配置中读取 FesSms 服务器的 URL，返回一个 `SmsClient` 实例。  
`"CS.Workshop"` 是服务名，对应 `web.xml` 中注册的 Config 类。

---

### 阶段二：SmsClient 通过 HTTP 传送任务

`SmsClient` 把任务（`SmsTask`）**序列化**（Java Object Serialization）后，通过 **HTTP POST** 发送到 FesSms 服务器的 `/SmsServlet` 端点。

```
POST http://<FesSms服务器>/SmsServlet
Content-Type: application/octet-stream

[二进制序列化数据: serviceName + SmsTask对象]
```

这个设计的好处是：**业务模块与短信发送模块完全解耦**，业务模块不需要知道 SMPP 协议，只需丢一个"任务"给 FesSms 服务器就好。

---

### 阶段三：SmsServlet 接收并分派

`SmsServlet`（`fes.helper.sms.service.SmsServlet`）是 FesSms 的入口：

```
HTTP POST 进来
    ↓
反序列化：取出 serviceName（如 "CS.Workshop"）和 SmsTask
    ↓
调用 SmsService.getHandler(serviceName, configClassNames)
    ↓
返回对应的 SmsHandler（连接通道）
    ↓
执行 task.execute(handler) → 发送短信
    ↓
把结果序列化回传给调用者
```

`SmsServlet` 还支持 GET 请求 `?reset` 参数，用于**重置所有 SMSC 连接**（运维用途）。

---

### 阶段四：SmsService 管理连接池

`SmsService`（`fes.helper.sms.service.SmsService`）维护着一个 **`Map<serviceName, SmsHandler>`** 连接池：

- **第一次**请求某个服务时 → 读取对应 Config 类 → 创建新的 `SmsHandler` → **与 SMSC 建立 SMPP 连接**（`bind`）→ 存入 Map 缓存
- **后续**请求同一服务 → 直接复用已有连接，**不重新连接**
- 连接断开时 → 自动尝试 `rebind`（重新连接），失败则切换备用服务器（Primary → Secondary）

---

### 阶段五：SmsHandler 用 SMPP 发送短信

`SmsHandler`（`fes.helper.sms.SmsHandler`）是真正调用 SMPP 协议发送短信的类：

```
handler.sendSms(phoneNumber, message, isChinese)
    ↓
构造 SubmitSM PDU（SMPP 协议的短信提交数据包）
    ↓
设置编码（英文：ASCII / 中文：UCS-2 或 Big5）
    ↓
session.submit(submitSM)  ← 通过 TCP 连接发给 SMSC
    ↓
SMSC 返回 SubmitSMResp（含 Message ID）
    ↓
返回 Message ID 给调用方
```

支持的发送方式：

| 方法 | 说明 |
|------|------|
| `sendSms(..., chinese)` | 自动选择 ASCII 或 Big5 编码 |
| `sendSmsUtf8(...)` | 强制使用 UTF-8（UCS-2）编码，适合中文 |
| `submit()` | 底层提交，需要手动设置所有参数 |

---

### 完整流程总结

```
用户在前端操作
    → 业务模块（FesWeb/FesSoap）产生发短信需求
    → SmsClient 序列化任务，HTTP POST → FesSms/SmsServlet
    → SmsServlet 交给 SmsService 找到对应连接通道
    → SmsHandler 通过已建立的 SMPP Session 发 SubmitSM 给 SMSC
    → SMSC 把短信投递到用户手机
    → 用户收到短信 📱
```

---

## 5. 核心类说明

| 类名 | 位置 | 职责 |
|------|------|------|
| `SmsClient` | `FesShared/.../sms/SmsClient.java` | **调用方入口**。业务模块使用此类发送任务到 FesSms 服务器 |
| `SmsTask` | `FesShared/.../sms/SmsTask.java` | **任务接口**。定义 `execute(handler)` 方法，可序列化传输 |
| `SmsServlet` | `FesSms/.../sms/service/SmsServlet.java` | **HTTP 入口**。接收 POST 请求，反序列化并执行任务 |
| `SmsService` | `FesSms/.../sms/service/SmsService.java` | **连接管理器**。维护 serviceName → SmsHandler 的连接缓存 |
| `SmsHandler` | `FesShared/.../sms/SmsHandler.java` | **发送引擎**。封装 SMPP Session，实际调用 `com.logica.smpp` 库 |
| `SmsConfig` | `FesShared/.../sms/SmsConfig.java` | **连接配置基类**。各业务 Config 类继承此类提供连接参数 |

---

## 6. Config 配置类——各业务模块的 SMSC 连接设定

每个业务模块发短信时使用不同的"账号"连接到 SMSC（或者完全不同的 SMSC），这是通过各自的 **Config 类**实现的。

### Config 类需要提供的参数

| 方法 | 说明 | 示例值 |
|------|------|------|
| `getServer()` | SMSC 服务器 IP（主） | `172.28.33.206` |
| `getServer2()` | SMSC 服务器 IP（备用） | （可选）|
| `getPort()` | SMSC 端口号 | `9501` |
| `getSystemId()` | 登录 SMSC 用的账户名 | `CallGuard` |
| `getPassword()` | 登录密码 | `call` |
| `getSystemType()` | 系统类型（部分 SMSC 需要）| 通常为空 |
| `getSource()` | 短信发件号码（OA，Originating Address） | `18888` |
| `getAddressRange()` | 本系统服务的号码范围 | `11*`（TON=1, NPI=1）|

### Config 参数的两种来源

**方式一：硬编码在 Java 类中**（如 `CallGuardRegSmsConfig`）

```java
public String getServer() { return "172.31.101.194"; }
public String getSystemId() { return "CallGuard"; }
public String getPassword() { return "call"; }
```

适合参数不经常变化、不需要运维动态修改的场景。

**方式二：从数据库读取**（如 `SABMSignSMSConfig`、`SAHPCSMSConfig`）

```java
// SABMSignSMSConfig 从 mms_sms_config 表读取
String sql = "select sys_id, sys_type, sys_pwd, oa_number, server_url " +
             "from mms_sms_config where source_module = 'SIGN_BACK' and msg_type = 'SMS'";

// SAHPCSMSConfig 从 ext_typdesc 表读取
String sql = "select * from ext_typdesc where typdesctblname = 'HPC-SMS-SETTING' and typdescclass = 'A'";
```

适合需要在不重启服务器的情况下修改 SMSC 连接配置的场景。

### 现有 Config 类列表

| Config 类 | 所属模块 | 业务含义 |
|-----------|---------|---------|
| `fes.cs.CallGuardRegSmsConfig` | CS（客户服务）| Call Guard 来电防护注册 |
| `fes.cs.workshop.CSHandsetTrainingSmsConfig` | CS Workshop | 手机培训预约通知 |
| `fes.sa.SABMSignSMSConfig` | SA（销售）| BM 签约回签通知 |
| `fes.sa.SAHPCSMSConfig` | SA | 手机购买同意书通知 |
| `fes.pr.PRSMSConfig` | PR（促销留客）| 一般促销优惠 SMS |
| `fes.pr.PRCCSMSConfig` | PR | Cold Call（冷打电话）促销 |
| `fes.pr.PRHPPSMSConfig` | PR | HPP（手机分期付款计划）促销 |
| `fes.pr.PRWFBSMSConfig` | PR | WFB（无线宽带）促销 |
| `fes.pr.PRFBBSMSConfig` | PR | FBB（固定宽带）促销 |
| `fes.jupiter.contactassist.ContactAssistSmsConfig` | Fixedline | 固网 HelpNow 到户支援通知 |
| `fes.jupiter.relocation.HzRelocSmsConfig` | Fixedline | 固网搬迁/注册通知 |
| `fes.jupiter.homeassist.HomeAssistantSmsConfig` | Fixedline | 固网 Home Assistant 通知 |
| `fes.oc.OCSmsConfig` | OC（网上商店）| 网上商店订单通知（已注释，暂停）|
| `pos.inshop_xfr.ecomm.InvRSSmsConfig` | POS / eComm | 库存预留系统通知 |

---

## 7. 白名单机制（UAT 环境保护）

### 问题背景

在 UAT（User Acceptance Testing，用户验收测试）和 STAGE（预生产）环境中，数据库里有真实用户的手机号码。如果测试时不加保护，系统可能会把"测试短信"发送给真实用户，造成骚扰。

### 解决方案：SMS 白名单

在 `web.xml` 中配置：

```xml
<!-- UAT 环境：只发给白名单号码 -->
<env-entry>
    <env-entry-name>UAT/SMS.WhitelistOnly</env-entry-name>
    <env-entry-value>true</env-entry-value>
</env-entry>

<!-- STAGE 环境：同样只发给白名单号码 -->
<env-entry>
    <env-entry-name>STAGE/SMS.WhitelistOnly</env-entry-name>
    <env-entry-value>true</env-entry-value>
</env-entry>
```

当 `SMS.WhitelistOnly = true` 时，`SmsService` 在每次发短信前会执行以下检查：

```java
// 查询数据库白名单
SELECT 1 FROM sms_white_list WHERE subr_num = '目标手机号' AND valid = 'Y'

// 如果不在白名单内 → 跳过，不发送，打印日志：
// "Phone Number not found in White List. Skipped sending SMS. [XXXXXXXX]"
```

> **注意**：香港手机号通常为 8 位数字，但系统传入的号码有时带 `852` 国际区号前缀（共 11 位）。白名单查询前会自动去掉 `852` 前缀，只用 8 位号码匹配。

### 环境对比

| 环境 | WhitelistOnly | 效果 |
|------|--------------|------|
| PROD（生产）| 无此配置（默认 false）| 所有号码都可以收到短信 |
| UAT | `true` | 只有白名单内的号码会收到短信 |
| STAGE | `true` | 只有白名单内的号码会收到短信 |

---

## 8. 已注册的短信服务一览

以下是 `web.xml` 中已注册的全部短信服务名，业务模块调用 `SmsClient` 时需要传入对应的 `serviceName`：

| 服务名（serviceName） | 对应 Config 类 | 说明 |
|----------------------|---------------|------|
| `CS.CallGuardReg` | `fes.cs.CallGuardRegSmsConfig` | CS 来电防护注册 |
| `CS.Workshop` | `fes.cs.workshop.CSHandsetTrainingSmsConfig` | CS 手机培训 |
| `Fixedline.HelpNow` | `fes.jupiter.contactassist.ContactAssistSmsConfig` | 固网到户支援 |
| `Fixedline.Relocation` | `fes.jupiter.relocation.HzRelocSmsConfig` | 固网搬迁注册 |
| `Fixedline.HomeAssistant` | `fes.jupiter.homeassist.HomeAssistantSmsConfig` | 固网家居助理 |
| `BMSignBack` | `fes.sa.SABMSignSMSConfig` | SA 签约回签通知 |
| `PROffer` | `fes.pr.PRSMSConfig` | PR 一般促销 |
| `PRCCOffer` | `fes.pr.PRCCSMSConfig` | PR Cold Call 促销 |
| `PRHPPOffer` | `fes.pr.PRHPPSMSConfig` | PR HPP 促销 |
| `PRWFBOffer` | `fes.pr.PRWFBSMSConfig` | PR WFB 促销 |
| `PRFBBOffer` | `fes.pr.PRFBBSMSConfig` | PR FBB 促销 |
| `SAHPC` | `fes.sa.SAHPCSMSConfig` | SA 手机购买同意书 |
| `INV.InvRSSMS` | `pos.inshop_xfr.ecomm.InvRSSmsConfig` | 库存预留系统 |

---

---

## 9. 各业务模块发送的短信内容分析

### 9.1 SA（Sales Administration，销售管理）模块

SA 模块是发短信最多的模块，主要围绕"签约"和"购机"两个核心流程，统一使用 **`BMSignBack`** 服务（SMSC 连接账号为 `SABMSignSMSConfig`）。

#### SA 签约回签通知（BM Sign Back）

- **触发时机**：Business Manager（BM 系统）签约成功后，需要客户在手机上确认签约（即"回签"）
- **短信内容**：包含客户订阅号码（`subr_num`）和一个**图片链接（image_link）**，客户点击链接可以查看/签署合约
- **内容模板**：从数据库动态读取 `msg_content_template`，用 `MessageFormat` 填入 `{0}=subr_num, {1}=image_link`
- **代码位置**：`FesWeb/src/fes/sa/LoginPurchaseConsentServlet.java`
- **备注**：支持 SMS（纯文字）和 MMS（含图片）两种模式，根据客户手机类型自动选择

```
示例短信内容（英文模板）：
Dear customer, please click the link to complete your sign-back for 
subscriber XXXXXXXX: https://fes.smartone.com/signback/...
```

#### SA 优惠礼品券通知（Premium Gift SMS）

- **触发时机**：客户完成签约并获得优惠礼品（GF，Gift）时发送兑换券
- **短信内容**：包含礼品券（`gf_ecoupon`）和兑换信息，记录到 `gf_sms_log` 日志表
- **代码位置**：`FesWeb/src/fes/sa/pg/SAPremGiftSMSHandler.java`

#### SA SIM 卡更换通知

- **触发时机**：客户办理 SIM 卡更换（SIM Replace）时
- **内容模板**：含 `<SUBRNUM>`（订阅号码占位符）和 `<DATE>`（日期占位符），发送前会替换
- **代码位置**：`FesShared/src/fes/sa/sim_replace/SIMReplaceHandler.java`

#### SA 网上商城订单发货通知（OC Apps / Online Store）

- **触发时机**：网上商城（Online Commerce）订单发货时
- **短信内容**：发货通知，包含快递信息
- **代码位置**：`FesWeb/src/fes/ocApps/SendShipOrderEmail.java`、`SendShipOrderEmail_Ph2.java`

#### SA 移动预审批通知（TM Mobile Pre-Approval）

- **触发时机**：预审批（Pre-Approval）流程完成时，通知销售员/客户
- **发送者**：早期使用 `"SmarTone"` 作为发件名，现已改为动态 OA（由 `SmsOAHandler` 决定）
- **代码位置**：`FesWeb/src/pos/main/TMMobilePreAppr_Handler.java`

---

### 9.2 CS（Customer Service，客户服务）模块

CS 模块的短信主要用于**服务通知和预约确认**，使用多个不同的 SMSC 账号。

#### CS Workshop 维修预约确认

- **触发时机**：客户预约手机维修/培训（Workshop/Handset Training）成功后自动发送
- **发送方式**：使用独立线程（`BookingSmsThread`）异步发送，不阻塞主流程
- **短信内容**：预约确认信息，由业务层组装后传入，内容因服务类型而异
- **发件人**：`"SmarTone"`（字母发件人，即 Alpha Sender）
- **服务名**：`CS.Workshop`（`CSHandsetTrainingSmsConfig`）
- **代码位置**：`FesSoap/src/fes/cs/booking/contentTransfer/BookingSmsThread.java`
- **日志**：发送结果记录到 `BookingSmsHandler.createAutoSMSLog()`

#### CS 文件发送（Doc Delivery / SmsDoc）

- **触发时机**：客服人员在系统中选择向客户发送文档（如合约、条款）时
- **短信内容**：从数据库模板读取，用 `template.toText(tagValues)` 填入动态值（标签替换）
- **OA（发件号码）选择规则**：
  - 默认：使用 `meta.getInBaseOa()`（本网客户 OA）
  - 非本网用户（如 MNP 携号转入）：改用 `meta.getOutBaseOa()`（外网 OA）
  - HPP 旧设备用户：改用特殊 `OLD_HPP_OA`（从 `ext_typdesc` 表读取）
- **服务名**：`CS.Workshop`
- **代码位置**：`FesSoap/src/fes/cs/docDelivery/SmsDoc.java`

#### CS Call Guard 来电防护注册

- **触发时机**：客户注册 Call Guard（来电防护服务）时
- **短信内容**：通过 `MmsDoc` 或 `MmsMetaData` 发送，内容来自数据库模板
- **服务名**：`CS.CallGuardReg`（`CallGuardRegSmsConfig`，IP 硬编码 `172.31.101.194:9500`）
- **代码位置**：`FesSoap/src/fes/cs/docDelivery/MmsDoc.java`

#### CS 屏幕保险报价通知（Screen Coverage）

- **触发时机**：客户申请屏幕保险后，系统发送报价结果通知
- **服务名**：`CS.Workshop`
- **代码位置**：`FesWeb/src/fes/repair/screen/ScreenCoverageHandler.java`

#### CS AES 自动回复短信（AsyncSmsTask）

- **触发时机**：AES（自动短信服务）接收到来自用户的关键词短信后，自动回复
- **发件人**：从数据库 `aes_service` 表的 `msg_src` 字段读取（默认 `"#SmarTone"`）
- **短信内容**：`replyInfo.getMessage()`，即预设的自动回复内容
- **特别之处**：这是系统中唯一处理**接收短信→自动触发回复**的模块
- **代码位置**：`FesSoap/src/com/mofinity/aes/AsyncSmsTask.java`

---

### 9.3 PR（Proactive Retention，主动留客）模块

PR 模块负责向即将离网或有升级需求的客户发送**促销优惠**短信，使用专属 SMSC 账号（各 Config 从数据库读取）。

| 短信类型 | 服务名 | 适用客户 | 说明 |
|---------|-------|---------|------|
| 一般升级优惠 | `PROffer` | 到期升级客户 | 一般续约/升级优惠通知 |
| Cold Call 促销 | `PRCCOffer` | 主动致电目标客户 | 冷打电话后跟进的优惠短信 |
| HPP 分期付款 | `PRHPPOffer` | HPP 计划到期客户 | 手机分期付款（Handset Purchase Plan）优惠 |
| WFB 无线宽带 | `PRWFBOffer` | 无线宽带客户 | Wireless Fixed Broadband 优惠 |
| FBB 固定宽带 | `PRFBBOffer` | 固网宽带客户 | Fixed Broadband 优惠 |

- **短信内容**：由 CS/PR 系统人员撰写，通过 `PrSmsHistory` 类的模板系统（`Template.toText(tagValues)`）发送
- **发送历史**：发送记录存档到历史表，供后续查询
- **代码位置**：`FesSoap/src/fes/cs/docDelivery/PrSmsHistory.java`

---

### 9.4 Fixedline / Jupiter（固网）模块

| 短信类型 | 服务名 | 说明 |
|---------|-------|------|
| HelpNow 到户支援 | `Fixedline.HelpNow` | 固网技术人员上门预约确认通知 |
| 搬迁/注册 | `Fixedline.Relocation` | 固网服务搬迁或新装申请确认 |
| Home Assistant | `Fixedline.HomeAssistant` | 家居助理服务预约通知 |

---

### 9.5 POS / eComm 模块

#### 库存预留取货通知（Inventory Reserve System）

- **触发时机**：网上预留货品的客户可以到门店取货时，发送取货通知
- **短信内容**：`resendObj.getSmsContent()`，来自数据库模板
- **特别之处**：OA 号码格式有两种，系统会根据 Config 的 `smcSourceTon/Npi` 自动选择：
  - `TON=1/NPI=1`：使用本地号码格式（如 `61194733`）
  - `TON=5/NPI=0`：使用字母发件人格式（如 `SmarTone`）
- **服务名**：`INV.InvRSSMS`
- **代码位置**：`FesWeb/src/pos/inshop_xfr/ecomm/resendPickupNotify/InvResResendHandler.java`

---

### OA（Originating Address，发件人）的演变

从代码注释中可以看到系统对发件人号码的多次修改历史：

```
早期：使用数据库读取的本地手机号码 (例如 61194733)
          ↓ 2018年修改
中期：改为字母发件人 "SmarTone"（更专业，用户能看到品牌名）
          ↓ 2023年修改 (SR0042479, M20231108)
现在：改由 SmsOAHandler.getOverrideOA("SMS", "SIGN_BACK") 动态决定
      （可在不重启服务器的情况下通过数据库修改发件人）
```

---

## 10. `com.logica.smpp` 库详解

### 这个库是内部自制的吗？

**是的，这是内部维护的定制版本。** 虽然名字叫 `com.logica.smpp`，原型来自一个同名的开源 Java SMPP 库（Logica SMPP，已停止维护），但本项目将其打包成 `smpp.jar`（位于 `FesLib/smpp.jar`）并进行了定制修改。

FES 团队在其基础上编写了大量包装代码（即 `SmsHandler.java`），添加了：
- 长短信自动分段（Concat SMS / SAR）
- UCS-2 / Big5 / GSM 编码自动切换
- 发送速率限制（throttle）
- 自动重连机制

### 库提供了哪些核心类？

```
com.logica.smpp
    │
    ├── Session                   ← 核心：SMPP 会话，管理整个连接生命周期
    ├── TCPIPConnection           ← 底层 TCP/IP 连接封装
    ├── SmppException             ← SMPP 层异常
    │
    ├── pdu/                      ← PDU（Protocol Data Unit，协议数据单元）相关
    │    ├── BindTransmitter       ← 绑定请求（只发送模式）
    │    ├── BindReceiver          ← 绑定请求（只接收模式）
    │    ├── BindTransciever       ← 绑定请求（收发双向模式）
    │    ├── BindResponse          ← 绑定响应
    │    ├── SubmitSM              ← 提交短信请求（最核心！）
    │    ├── SubmitSMResp          ← 提交短信响应（含 Message ID）
    │    ├── DeliverSM             ← 接收短信（SMSC 主动推送过来的）
    │    ├── QuerySM / QuerySMResp ← 查询短信状态
    │    ├── CancelSM / CancelSMResp ← 取消短信
    │    ├── UnbindResp            ← 断开连接响应
    │    ├── Address               ← 地址对象（含 TON/NPI/号码）
    │    ├── AddressRange          ← 地址范围（用于 bind 时声明服务范围）
    │    └── Data                  ← 常量定义（编码常量、状态码等）
    │
    └── util/debug/               ← 工具类
```

### 关键概念：PDU（Protocol Data Unit，协议数据单元）

PDU 是 SMPP 协议的"数据包"单位，类似于快递包裹的"包装盒"。每次通信都是发送/接收一个 PDU。

```
┌─────────────────────────────────────────┐
│              PDU 结构                    │
├──────────┬──────────────────────────────┤
│  Header  │  Command Length (4 bytes)    │
│  (头部)   │  Command ID    (4 bytes)    │
│          │  Command Status(4 bytes)    │
│          │  Sequence Number(4 bytes)   │
├──────────┼──────────────────────────────┤
│  Body    │  各种参数（发件人、收件人、   │
│  (正文)   │  短信内容、编码方式等）      │
└──────────┴──────────────────────────────┘
```

### `Session` 类的工作原理

`Session` 是整个 SMPP 通信的核心，它封装了 TCP 连接上的所有 PDU 收发：

```
new TCPIPConnection(ip, port)    ← 建立 TCP Socket 连接
        ↓
new Session(connection)          ← 创建 SMPP 会话
        ↓
session.bind(BindTransmitter)    ← 登录 SMSC（认证）
        ↓
session.submit(SubmitSM)         ← 发送短信（可循环调用）
        ↓
session.unbind()                 ← 退出登录（断开连接）
```

### TON 和 NPI 是什么？

代码中经常看到 `(byte) ton, (byte) npi`，这是 SMPP 协议中描述**号码类型**的两个字段：

| TON 值 | 含义 | 使用场景 |
|--------|------|---------|
| `0` | Unknown（未知）| 通用 |
| `1` | International（国际格式）| 如 `85290123456` |
| `5` | Alphanumeric（字母数字）| 如 `"SmarTone"` |

| NPI 值 | 含义 |
|--------|------|
| `0` | Unknown |
| `1` | ISDN / Telephone numbering plan（标准电话号码）|

**本系统中常见组合：**
```java
(byte) 5, (byte) 0, "SmarTone"    // 字母发件人（用户看到的是 "SmarTone"）
(byte) 1, (byte) 1, "85290123456" // 标准国际格式号码
```

### `SmsHandler.java` 对库的封装与增强

FES 团队的 `SmsHandler.java` 在原始 `com.logica.smpp` 库基础上做了很多增强：

| 增强功能 | 实现方式 |
|---------|---------|
| **自动编码选择** | 中文用 UCS-2（`dataCoding=8`），英文用 GSM-7/ASCII（`dataCoding=0`）|
| **Big5 → UTF-16 转码** | `convert(shortMessage, "BIG5", "UTF16")` |
| **GSM 字符集检测** | `GsmCharset.isEncodeableInGsm0338()` 判断是否需要 UCS-2 |
| **长短信自动分段** | 英文 160 字/段，中文 70 字/段；长于此自动分割并用 SAR 参数串联 |
| **Concat SMS（串联短信）** | 用 `setSarMsgRefNum / setSarTotalSegments / setSarSegmentSeqnum` 标记分段 |
| **发送速率限制** | `throttle()`：按 `maxRate`（每秒最多 N 条）控制发送频率 |
| **连接超时设置** | TCP 超时 30 秒（`connection.setReceiveTimeout(30*1000)`）|
| **重连前先 Unbind** | 2025年11月新增，避免 CPU 过高问题 |

---

*文档由 GitHub Copilot 根据源代码自动生成，如有更新请同步修改。*



