# Plan: FesSms 系统分析文档

FesSms 是 FES（Front-End System，前端服务系统）的 SMS 短信发送子系统。它并非直接接收业务请求，而是作为一个**独立的短信发送服务器**，通过 SMPP 协议连接到电信运营商的 SMSC（短信中心），其他业务模块（FesWeb、FesSoap 等）通过 HTTP 请求调用它来发短信给用户。以下是完整的文档生成计划：

---

## Steps

1. **整体架构说明**：解释 FesSms 是"短信服务器"角色，介绍 [FesSms 项目](C:\WorkSoftware\a_program\Fes\fesapplication-uat\FesSms) 与 FesWeb、FesSoap 业务模块的分工关系。

2. **SMPP 协议科普**：用通俗语言解释什么是 SMPP（Short Message Peer-to-Peer）协议、什么是 SMSC（短信中心），说明短信是如何从服务器"走到"用户手机的物理链路。

3. **短信发送流程逐步解析**：分 5 个阶段图文说明：
   - 业务触发（如用户签约）→ 业务模块（FesWeb/FesSoap）调用 [`SmsClient.java`](c:\WorkSoftware\a_program\Fes\fesapplication-uat\FesShared\src\fes\helper\sms\SmsClient.java)
   - SmsClient 通过 HTTP POST 把任务序列化发送到 FesSms 服务器的 [`SmsServlet.java`](C:\WorkSoftware\a_program\Fes\fesapplication-uat\FesSms\src\fes\helper\sms\service\SmsServlet.java)
   - SmsServlet 交给 [`SmsService.java`](C:\WorkSoftware\a_program\Fes\fesapplication-uat\FesSms\src\fes\helper\sms\service\SmsService.java) 获取对应的连接通道（`SmsHandler`）
   - `SmsHandler` 通过 SMPP Session 连接电信 SMSC，调用底层 `com.logica.smpp` 库发出短信
   - SMSC 把短信推送到目标手机号

4. **Config 类的作用**：解释 [`SABMSignSMSConfig.java`](C:\WorkSoftware\a_program\Fes\fesapplication-uat\FesSms\src\fes\sa\SABMSignSMSConfig.java) 等 Config 类，说明它们从数据库 `mms_sms_config` 表读取 SMSC 连接参数（IP、端口、账号密码、发件号码），不同业务模块对应不同 Config（SA签约、CS客服、PR公关等）。

5. **白名单机制与 UAT 环境保护**：解释 `sms_white_list` 白名单逻辑——在 UAT 测试环境中只有白名单内的手机号才会真正收到短信，防止测试时误发给真实用户。

6. **在 `FesSms` 目录下生成文档文件**：将以上内容汇总为 [`FesSms/README_FesSms_Architecture.md`](C:\WorkSoftware\a_program\Fes\fesapplication-uat\FesSms\README_FesSms_Architecture.md)，包含架构图（文字 ASCII 图）、流程图和各类说明。

---

## Further Considerations

1. **文档语言**：用中文撰写，专业术语用英文但是有翻译一下
2. **图表格式**：文档中需要流程图（Markdown 预览器支持渲染）也要纯 ASCII 文字图描述？
3. **深度范围**：先不进一步分析每个业务模块（SA签约、CS客服、PR）各自发什么内容的短信，大概简单说明就行，需要架构层面的说明

