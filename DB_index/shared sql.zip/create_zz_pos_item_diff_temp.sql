CREATE TABLE zz_pos_item_diff_temp (
    -- Old system fields
    subscriber        VARCHAR2(20),
    cellular          VARCHAR2(20),
    invoice_no        VARCHAR2(10),
    inv_date          DATE,
    inv_type          VARCHAR2(3),
    inv_amount        NUMBER(12,2),
    os_amount         NUMBER(12,2),
    charge_type       VARCHAR2(10),

    -- New system fields
    subscriber_nb     VARCHAR2(20),
    cellular_nb       VARCHAR2(20),
    invoice_no_nb     VARCHAR2(10),
    inv_date_nb       DATE,
    inv_type_nb       VARCHAR2(3),
    inv_amount_nb     NUMBER(12,2),
    os_amount_nb      NUMBER(12,2),
    charge_type_nb    VARCHAR2(10),

    -- Comparison metadata
    compare_status    VARCHAR2(2) ,  -- 1: exist in old but not new, 2: exist in new but not old
    remarks           VARCHAR2(100),
    create_date   DATE DEFAULT SYSDATE
);

-- Create index for better query performance
CREATE INDEX idx_pos_diff_temp_date ON zz_pos_item_diff_temp(create_date);
CREATE INDEX idx_pos_diff_temp_query ON zz_pos_item_diff_temp(create_date, compare_status);
CREATE INDEX idx_pos_diff_temp_status1 ON zz_pos_item_diff_temp(subscriber, cellular, invoice_no)
WHERE compare_status = '1';
CREATE INDEX idx_pos_diff_temp_status2 ON zz_pos_item_diff_temp(subscriber_nb, cellular_nb, invoice_no_nb)
WHERE compare_status = '2';




DROP PUBLIC SYNONYM zz_pos_item_diff_temp;
CREATE OR REPLACE PUBLIC SYNONYM zz_pos_item_diff_temp FOR FES.zz_pos_item_diff_temp;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.zz_pos_item_diff_temp TO FESJUPLD;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.zz_pos_item_diff_temp TO FES_BATCH_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.zz_pos_item_diff_temp TO FES_REPAIR_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.zz_pos_item_diff_temp TO FES_RPT_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.zz_pos_item_diff_temp TO FES_SA_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.zz_pos_item_diff_temp TO FES_USER_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.zz_pos_item_diff_temp TO SMART;
