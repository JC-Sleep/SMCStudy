CREATE TABLE ZZ_PSUB_REF_diff_temp (
    Subscriber VARCHAR2(20),
    Account_no VARCHAR2(20),
    Cellular VARCHAR2(20),
    Stat VARCHAR2(1),
    Sim_No VARCHAR2(20),
    IMEI VARCHAR2(20),
    Unbill_amt NUMBER(12,2),
    Unbill_amt_sign VARCHAR2(1),
    Act_date DATE,
    S_Off_date DATE,
    Bill_day NUMBER(5,0),
    DEALER VARCHAR2(20),
    CUST_TYPE VARCHAR2(40),
    RPLAN VARCHAR2(5),
    DISCON_REASON VARCHAR2(40),
    LAST_PAYMENT_DATE DATE,
    PAYMENT_METHOD  VARCHAR2(40),
    DIVERT_CODE VARCHAR2(15),
    Subscriber_NB VARCHAR2(20),
    Account_no_NB VARCHAR2(20),
    Cellular_NB VARCHAR2(20),
    Stat_NB VARCHAR2(1),
    Sim_No_NB VARCHAR2(20),
    IMEI_NB VARCHAR2(20),
    Unbill_amt_NB NUMBER(12,2),
    Unbill_amt_sign_NB VARCHAR2(1),
    Act_date_NB DATE,
    S_Off_date_NB DATE,
    Bill_day_NB NUMBER(5,0),
    DEALER_NB VARCHAR2(20),
    CUST_TYPE_NB VARCHAR2(40),
    RPLAN_NB VARCHAR2(5),
    DISCON_REASON_NB VARCHAR2(40),
    LAST_PAYMENT_DATE_NB DATE,
    PAYMENT_METHOD_NB  VARCHAR2(40),
    DIVERT_CODE_NB VARCHAR2(15),
    remarks  VARCHAR2(100),
    compare_status VARCHAR2(2),
    create_date DATE DEFAULT SYSDATE
);
-- Create index for better query performance
CREATE INDEX idx_ZZ_PSUB_REF_diff_temp_stat ON ZZ_PSUB_REF_diff_temp(compare_status);
CREATE INDEX idx_diff_temp_main ON ZZ_PSUB_REF_diff_temp(create_date, compare_status);
CREATE INDEX idx_diff_temp_coalesce_key ON ZZ_PSUB_REF_diff_temp(
    NVL(Subscriber, Subscriber_NB),
    NVL(Cellular, Cellular_NB)
);
CREATE INDEX idx_diff_temp_old_only ON ZZ_PSUB_REF_diff_temp(Subscriber, Cellular)
WHERE compare_status = '1';
CREATE INDEX idx_diff_temp_new_only ON ZZ_PSUB_REF_diff_temp(Subscriber_NB, Cellular_NB)
WHERE compare_status = '2';
CREATE INDEX idx_diff_temp_export ON ZZ_PSUB_REF_diff_temp(
    TRUNC(create_date), compare_status,
    NVL(Subscriber, Subscriber_NB),
    NVL(Cellular, Cellular_NB)
);


--DROP PUBLIC SYNONYM ZZ_PSUB_REF_diff_temp;
CREATE OR REPLACE PUBLIC SYNONYM ZZ_PSUB_REF_diff_temp FOR FES.ZZ_PSUB_REF_diff_temp;


GRANT DELETE, INSERT, SELECT, UPDATE ON FES.ZZ_PSUB_REF_diff_temp TO FESJUPLD;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.ZZ_PSUB_REF_diff_temp TO FES_BATCH_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.ZZ_PSUB_REF_diff_temp TO FES_REPAIR_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.ZZ_PSUB_REF_diff_temp TO FES_RPT_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.ZZ_PSUB_REF_diff_temp TO FES_SA_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.ZZ_PSUB_REF_diff_temp TO FES_USER_ROLE;

GRANT DELETE, INSERT, SELECT, UPDATE ON FES.ZZ_PSUB_REF_diff_temp TO SMART;
